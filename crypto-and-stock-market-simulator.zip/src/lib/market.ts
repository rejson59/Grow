import { ASSETS, type AssetDefinition } from "@/lib/content";

export type Range = "1D" | "1W" | "1M" | "3M";
export type MarketQuote = {
  symbol: string;
  price: number | null;
  changePercent: number | null;
  updatedAt: string | null;
  source: string;
  sparkline: number[];
  sparklineApproximate?: boolean;
};
export type ChartPoint = { time: number; price: number };
export type MarketChart = { symbol: string; range: Range; points: ChartPoint[]; source: string; note: string };
export type MarketData = { assets: MarketQuote[]; chart: MarketChart; fetchedAt: string };

type YahooResult = {
  meta?: { regularMarketPrice?: number; regularMarketChangePercent?: number; regularMarketTime?: number; previousClose?: number; chartPreviousClose?: number };
  timestamp?: number[];
  indicators?: { quote?: { close?: (number | null)[] }[] };
};
type CoinGeckoMarket = {
  id: string;
  current_price: number;
  price_change_percentage_24h: number | null;
  last_updated: string;
  sparkline_in_7d?: { price?: number[] };
};

const cryptoAssets = ASSETS.filter((asset) => asset.category === "crypto");
const stockAssets = ASSETS.filter((asset) => asset.category === "stock");
const yahooHeaders = { "User-Agent": "Mozilla/5.0 (compatible; GrowSimulator/1.0)", Accept: "application/json" };

async function fetchJson(url: string, seconds: number, fresh = false, headers?: Record<string, string>): Promise<unknown> {
  const response = await fetch(url, {
    headers: headers ?? { Accept: "application/json" },
    ...(fresh ? { cache: "no-store" as const } : { next: { revalidate: seconds } }),
    signal: AbortSignal.timeout(9000),
  });
  if (!response.ok) throw new Error(`Market source returned ${response.status}`);
  return response.json();
}

function positive(value: unknown): number | null {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : null;
}

function emptyQuote(symbol: string): MarketQuote {
  return { symbol, price: null, changePercent: null, updatedAt: null, source: "Niedostępne", sparkline: [] };
}

function parseYahoo(data: unknown): YahooResult | null {
  const chart = (data as { chart?: { result?: YahooResult[] } })?.chart;
  return chart?.result?.[0] ?? null;
}

async function getStockQuote(asset: AssetDefinition, fresh = false): Promise<MarketQuote> {
  const data = await fetchJson(`https://query1.finance.yahoo.com/v8/finance/chart/${asset.marketSymbol}?range=1mo&interval=1d`, 75, fresh, yahooHeaders);
  const result = parseYahoo(data);
  if (!result) throw new Error("Brak danych giełdowych");
  const closes = (result.indicators?.quote?.[0]?.close ?? []).filter((n): n is number => typeof n === "number" && Number.isFinite(n) && n > 0);
  const price = positive(result.meta?.regularMarketPrice) ?? closes.at(-1) ?? null;
  const prev = positive(result.meta?.previousClose) ?? positive(result.meta?.chartPreviousClose);
  const percent = typeof result.meta?.regularMarketChangePercent === "number"
    ? result.meta.regularMarketChangePercent
    : price && prev ? ((price / prev) - 1) * 100 : null;
  return {
    symbol: asset.symbol,
    price,
    changePercent: percent,
    updatedAt: result.meta?.regularMarketTime ? new Date(result.meta.regularMarketTime * 1000).toISOString() : null,
    source: "Yahoo Finance · GPW (możliwe opóźnienie)",
    sparkline: closes.slice(-22),
  };
}

type FxPoint = { time: number; rate: number };

async function getUsdPlnHistory(period: string, interval: string): Promise<FxPoint[]> {
  const data = await fetchJson(`https://query1.finance.yahoo.com/v8/finance/chart/PLN=X?range=${period}&interval=${interval}`, 180, false, yahooHeaders);
  const result = parseYahoo(data);
  const closes = result?.indicators?.quote?.[0]?.close ?? [];
  return (result?.timestamp ?? []).map((time, index) => ({ time: time * 1000, rate: closes[index] }))
    .filter((point): point is FxPoint => typeof point.rate === "number" && Number.isFinite(point.rate) && point.rate > 0);
}

function rateAt(history: FxPoint[], time: number): number {
  if (!history.length) return 1;
  let left = 0;
  let right = history.length - 1;
  while (left < right) {
    const middle = Math.ceil((left + right) / 2);
    if (history[middle].time <= time) left = middle;
    else right = middle - 1;
  }
  return history[left].rate;
}

async function getCoinGeckoQuotes(): Promise<MarketQuote[]> {
  const ids = cryptoAssets.map((a) => a.coinId).join(",");
  const data = await fetchJson(`https://api.coingecko.com/api/v3/coins/markets?vs_currency=pln&ids=${ids}&sparkline=true&price_change_percentage=24h`, 50);
  if (!Array.isArray(data)) throw new Error("Brak danych CoinGecko");
  const coins = data as CoinGeckoMarket[];
  // The public markets endpoint sometimes returns a USD sparkline despite vs_currency=pln.
  // Detect mismatched units rather than displaying an apparently 75,000 PLN Bitcoin chart.
  const needsFx = coins.some((coin) => {
    const last = coin.sparkline_in_7d?.price?.at(-1);
    return last && coin.current_price / last > 1.5;
  });
  let fxHistory: FxPoint[] = [];
  if (needsFx) {
    try { fxHistory = await getUsdPlnHistory("10d", "1h"); }
    catch (error) { console.warn("Historical FX unavailable; using current implied conversion", error); }
  }
  return cryptoAssets.map((asset) => {
    const coin = coins.find((item) => item.id === asset.coinId);
    if (!coin || !positive(coin.current_price) || !coin.last_updated) return emptyQuote(asset.symbol);
    const end = new Date(coin.last_updated).getTime();
    if (!Number.isFinite(end) || Date.now() - end > 15 * 60 * 1000) return emptyQuote(asset.symbol);
    const raw = (coin.sparkline_in_7d?.price ?? []).filter((n) => typeof n === "number" && Number.isFinite(n) && n > 0).slice(-168);
    const last = raw.at(-1);
    const isDifferentCurrency = !!last && (coin.current_price / last > 1.5 || coin.current_price / last < 0.65);
    let sparkline = raw;
    if (isDifferentCurrency && last) {
      const currentRate = rateAt(fxHistory, end);
      const adjustment = coin.current_price / (last * currentRate);
      sparkline = raw.map((value, index) => {
        const time = end - (raw.length - 1 - index) * 60 * 60 * 1000;
        return Number((value * rateAt(fxHistory, time) * adjustment).toFixed(4));
      });
    }
    return {
      symbol: asset.symbol,
      price: coin.current_price,
      changePercent: typeof coin.price_change_percentage_24h === "number" ? coin.price_change_percentage_24h : null,
      updatedAt: coin.last_updated,
      source: "CoinGecko · PLN",
      sparkline,
      sparklineApproximate: isDifferentCurrency,
    };
  });
}

async function getUsdPln(fresh = false): Promise<number> {
  try {
    const data = await fetchJson("https://query1.finance.yahoo.com/v8/finance/chart/PLN=X?range=1d&interval=1d", 120, fresh, yahooHeaders);
    const rate = positive(parseYahoo(data)?.meta?.regularMarketPrice);
    if (rate) return rate;
  } catch { /* Use the official NBP reference rate as a last resort. */ }
  const data = await fetchJson("https://api.nbp.pl/api/exchangerates/rates/a/usd/?format=json", 3600, fresh);
  const rate = positive((data as { rates?: { mid?: number }[] })?.rates?.[0]?.mid);
  if (!rate) throw new Error("Brak kursu USD/PLN");
  return rate;
}

type BinanceTicker = { symbol: string; lastPrice: string; priceChangePercent: string; closeTime: number };

async function getBinanceQuotes(fresh = false): Promise<MarketQuote[]> {
  const symbols = cryptoAssets.map((a) => a.marketSymbol);
  const [data, fx] = await Promise.all([
    fetchJson(`https://data-api.binance.vision/api/v3/ticker/24hr?symbols=${encodeURIComponent(JSON.stringify(symbols))}`, 35, fresh),
    getUsdPln(fresh),
  ]);
  if (!Array.isArray(data)) throw new Error("Brak danych Binance");
  return cryptoAssets.map((asset) => {
    const ticker = (data as BinanceTicker[]).find((item) => item.symbol === asset.marketSymbol);
    const usdPrice = positive(ticker?.lastPrice);
    return {
      symbol: asset.symbol,
      price: usdPrice ? Number((usdPrice * fx).toFixed(4)) : null,
      changePercent: ticker && Number.isFinite(Number(ticker.priceChangePercent)) ? Number(ticker.priceChangePercent) : null,
      updatedAt: ticker?.closeTime ? new Date(ticker.closeTime).toISOString() : null,
      source: "Binance (USDT) × USD/PLN · wycena przybliżona",
      sparkline: [],
    };
  });
}

async function getCryptoQuotes(): Promise<MarketQuote[]> {
  let primary: MarketQuote[] | null = null;
  try {
    primary = await getCoinGeckoQuotes();
    if (primary.every((quote) => quote.price !== null)) return primary;
  } catch (error) {
    console.warn("CoinGecko unavailable; using live fallback", error);
  }
  try {
    const fallback = await getBinanceQuotes();
    return cryptoAssets.map((asset, index) => primary?.[index]?.price != null ? primary[index] : fallback[index] ?? emptyQuote(asset.symbol));
  } catch (error) {
    console.warn("Crypto fallback unavailable", error);
    return primary ?? cryptoAssets.map((a) => emptyQuote(a.symbol));
  }
}

async function getStockChart(asset: AssetDefinition, range: Range): Promise<MarketChart> {
  const settings: Record<Range, { period: string; interval: string }> = {
    "1D": { period: "1d", interval: "5m" },
    "1W": { period: "5d", interval: "30m" },
    "1M": { period: "1mo", interval: "1d" },
    "3M": { period: "3mo", interval: "1d" },
  };
  const { period, interval } = settings[range];
  const data = await fetchJson(`https://query1.finance.yahoo.com/v8/finance/chart/${asset.marketSymbol}?range=${period}&interval=${interval}`, 75, false, yahooHeaders);
  const result = parseYahoo(data);
  const closes = result?.indicators?.quote?.[0]?.close ?? [];
  const points = (result?.timestamp ?? []).map((time, index) => ({ time: time * 1000, price: closes[index] }))
    .filter((point): point is ChartPoint => typeof point.price === "number" && Number.isFinite(point.price) && point.price > 0);
  return { symbol: asset.symbol, range, points, source: "Yahoo Finance · GPW", note: "Notowania GPW mogą być opóźnione. Po zamknięciu sesji widoczny jest ostatni dostępny kurs." };
}

async function getCoinGeckoChart(asset: AssetDefinition, range: Range): Promise<MarketChart> {
  const days: Record<Range, number> = { "1D": 1, "1W": 7, "1M": 30, "3M": 90 };
  const revalidate = range === "1D" ? 60 : range === "1W" ? 180 : 300;
  const data = await fetchJson(`https://api.coingecko.com/api/v3/coins/${asset.coinId}/market_chart?vs_currency=pln&days=${days[range]}`, revalidate);
  const raw = (data as { prices?: [number, number][] })?.prices;
  if (!Array.isArray(raw)) throw new Error("Brak historii CoinGecko");
  const points = raw.filter((p) => Array.isArray(p) && Number.isFinite(p[0]) && positive(p[1]))
    .map(([time, price]) => ({ time, price }));
  return { symbol: asset.symbol, range, points, source: "CoinGecko · PLN", note: "Historyczne ceny w PLN z CoinGecko." };
}

async function getBinanceChart(asset: AssetDefinition, range: Range, quote: MarketQuote): Promise<MarketChart> {
  const settings: Record<Range, { interval: string; limit: number }> = {
    "1D": { interval: "1h", limit: 25 },
    "1W": { interval: "4h", limit: 43 },
    "1M": { interval: "1d", limit: 31 },
    "3M": { interval: "1d", limit: 91 },
  };
  const { interval, limit } = settings[range];
  const data = await fetchJson(`https://data-api.binance.vision/api/v3/klines?symbol=${asset.marketSymbol}&interval=${interval}&limit=${limit}`, 90);
  if (!Array.isArray(data)) throw new Error("Brak historii Binance");
  const candles = (data as (string | number)[][]).map((row) => ({ time: Number(row[0]), usd: Number(row[4]) }))
    .filter((row) => Number.isFinite(row.time) && row.usd > 0);
  const last = candles.at(-1)?.usd;
  if (!last || !quote.price) throw new Error("Brak kursu przeliczeniowego");
  const factor = quote.price / last;
  return {
    symbol: asset.symbol, range,
    points: candles.map((row) => ({ time: row.time, price: Number((row.usd * factor).toFixed(4)) })),
    source: "Binance · wykres orientacyjny w PLN",
    note: "Historia z rynku USDT przeliczona bieżącą relacją do PLN. Dawne kursy PLN mogły być inne.",
  };
}

async function getCryptoChart(asset: AssetDefinition, range: Range, quote: MarketQuote): Promise<MarketChart> {
  try { return await getCoinGeckoChart(asset, range); }
  catch { /* The public history API can be rate-limited; transparently fall back. */ }
  if ((range === "1D" || range === "1W") && quote.sparkline.length > 5 && quote.updatedAt) {
    const values = range === "1D" ? quote.sparkline.slice(-25) : quote.sparkline;
    const end = new Date(quote.updatedAt).getTime();
    return {
      symbol: asset.symbol, range,
      points: values.map((price, index) => ({ time: end - (values.length - 1 - index) * 60 * 60 * 1000, price })),
      source: quote.sparklineApproximate ? "CoinGecko × USD/PLN · wycena orientacyjna" : "CoinGecko · PLN",
      note: quote.sparklineApproximate
        ? "Historia CoinGecko przeliczona historycznym kursem USD/PLN z Yahoo Finance i wyrównana do aktualnej ceny PLN. Wycena orientacyjna; godziny punktów są przybliżone."
        : "Ceny historyczne w PLN. Godziny punktów na wykresie są przybliżone.",
    };
  }
  return getBinanceChart(asset, range, quote);
}

export async function getMarketData(symbol: string, range: Range): Promise<MarketData> {
  const selected = ASSETS.find((a) => a.symbol === symbol) ?? ASSETS[0];
  const [crypto, ...stocks] = await Promise.all([
    getCryptoQuotes(),
    ...stockAssets.map(async (asset) => {
      try { return await getStockQuote(asset); }
      catch (error) { console.warn(`Quote unavailable: ${asset.symbol}`, error); return emptyQuote(asset.symbol); }
    }),
  ]);
  const quotes = [...crypto, ...stocks];
  const assets = ASSETS.map((asset) => quotes.find((quote) => quote.symbol === asset.symbol) ?? emptyQuote(asset.symbol));
  const quote = assets.find((item) => item.symbol === selected.symbol)!;
  let chart: MarketChart = { symbol: selected.symbol, range, points: [], source: "Niedostępne", note: "Nie udało się pobrać wykresu. Spróbuj odświeżyć dane." };
  try {
    chart = selected.category === "stock" ? await getStockChart(selected, range) : await getCryptoChart(selected, range, quote);
  } catch (error) { console.warn(`Chart unavailable: ${selected.symbol}`, error); }
  return { assets, chart, fetchedAt: new Date().toISOString() };
}

export async function getFreshQuote(symbol: string): Promise<MarketQuote> {
  const asset = ASSETS.find((item) => item.symbol === symbol);
  if (!asset) throw new Error("Nieznany instrument.");
  let quote: MarketQuote;
  if (asset.category === "stock") {
    quote = await getStockQuote(asset, true);
  } else {
    try {
      const data = await fetchJson(`https://api.coingecko.com/api/v3/simple/price?ids=${asset.coinId}&vs_currencies=pln&include_last_updated_at=true`, 0, true);
      const info = (data as Record<string, { pln?: number; last_updated_at?: number }>)?.[asset.coinId!];
      const price = positive(info?.pln);
      if (!price || !info?.last_updated_at || Date.now() - info.last_updated_at * 1000 > 10 * 60 * 1000) throw new Error("Nieaktualny kurs CoinGecko");
      quote = { symbol, price, changePercent: null, updatedAt: new Date(info.last_updated_at * 1000).toISOString(), source: "CoinGecko · PLN", sparkline: [] };
    } catch {
      const fallback = await getBinanceQuotes(true);
      quote = fallback.find((item) => item.symbol === symbol) ?? emptyQuote(symbol);
    }
  }
  if (!quote.price || !quote.updatedAt) throw new Error("Aktualny kurs jest chwilowo niedostępny. Spróbuj ponownie później.");
  const maxAge = asset.category === "crypto" ? 10 * 60 * 1000 : 8 * 24 * 60 * 60 * 1000;
  if (Date.now() - new Date(quote.updatedAt).getTime() > maxAge) throw new Error("Kurs jest zbyt stary, aby wykonać symulowaną transakcję.");
  return quote;
}
