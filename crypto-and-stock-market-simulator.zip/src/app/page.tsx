import Dashboard from "@/components/dashboard";
import { getMarketData, type MarketData } from "@/lib/market";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  let initialMarket: MarketData | null = null;
  try {
    initialMarket = await getMarketData("BTC", "1D");
  } catch (error) {
    console.error("Initial market data unavailable", error);
  }

  return <Dashboard initialMarket={initialMarket} />;
}
