import { NextRequest } from "next/server";
import { getMarketData, type Range } from "@/lib/market";
import { getAsset } from "@/lib/content";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const requestedSymbol = request.nextUrl.searchParams.get("symbol") ?? "BTC";
  const symbol = getAsset(requestedSymbol) ? requestedSymbol : "BTC";
  const requestedRange = request.nextUrl.searchParams.get("range") ?? "1D";
  const range: Range = (["1D", "1W", "1M", "3M"] as const).includes(requestedRange as Range)
    ? requestedRange as Range : "1D";

  try {
    const data = await getMarketData(symbol, range);
    return Response.json(data, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Market request failed", error);
    return Response.json({ error: "Nie udało się pobrać notowań. Spróbuj ponownie." }, { status: 503 });
  }
}
