import { randomUUID } from "node:crypto";
import { cookies } from "next/headers";
import { NextRequest } from "next/server";
import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { lessonCompletions, players, positions, transactions } from "@/db/schema";
import { getAsset, LESSONS } from "@/lib/content";
import { getFreshQuote } from "@/lib/market";
import type { GameResponse, GameState, GameTransaction } from "@/lib/game-types";

export const dynamic = "force-dynamic";

class ActionError extends Error {}
const roundMoney = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;
const moneyString = (value: number) => roundMoney(value).toFixed(2);

async function getPlayerId(): Promise<string> {
  const store = await cookies();
  const existing = store.get("grow_player")?.value;
  const id = existing && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(existing)
    ? existing : randomUUID();
  await db.insert(players).values({ id }).onConflictDoNothing();
  if (!existing || existing !== id) {
    store.set("grow_player", id, {
      httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production",
      path: "/", maxAge: 60 * 60 * 24 * 365,
    });
  }
  return id;
}

async function getState(playerId: string): Promise<GameState> {
  const [accountRows, positionRows, transactionRows, lessonRows] = await Promise.all([
    db.select().from(players).where(eq(players.id, playerId)).limit(1),
    db.select().from(positions).where(eq(positions.playerId, playerId)),
    db.select().from(transactions).where(eq(transactions.playerId, playerId)).orderBy(desc(transactions.createdAt), desc(transactions.id)),
    db.select().from(lessonCompletions).where(eq(lessonCompletions.playerId, playerId)),
  ]);
  const account = accountRows[0];
  if (!account) throw new Error("Nie znaleziono konta gracza");
  return {
    cash: Number(account.cash),
    totalDeposited: Number(account.totalDeposited),
    xp: account.xp,
    createdAt: account.createdAt.toISOString(),
    positions: positionRows.map((row) => ({ symbol: row.symbol, quantity: Number(row.quantity), costBasis: Number(row.costBasis) })),
    transactions: transactionRows.map((row): GameTransaction => ({
      id: row.id, kind: row.kind as GameTransaction["kind"], symbol: row.symbol,
      quantity: row.quantity === null ? null : Number(row.quantity),
      price: row.price === null ? null : Number(row.price), amount: Number(row.amount),
      createdAt: row.createdAt.toISOString(),
    })),
    completedLessons: lessonRows.map((row) => row.lessonId),
  };
}

export async function GET() {
  try {
    const id = await getPlayerId();
    return Response.json(await getState(id), { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Game state error", error);
    return Response.json({ error: "Nie można wczytać portfela. Spróbuj ponownie." }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const id = await getPlayerId();
    const body = await request.json() as Record<string, unknown>;
    const action = body.action;
    let execution: GameResponse["execution"];

    if (action === "deposit" || action === "withdraw") {
      const value = Number(body.amount);
      if (!Number.isFinite(value) || value <= 0 || value > 1_000_000 || roundMoney(value) <= 0) {
        throw new ActionError("Podaj kwotę od 0,01 zł do 1 000 000 zł.");
      }
      const amount = roundMoney(value);
      await db.transaction(async (tx) => {
        await tx.execute(sql`SELECT id FROM players WHERE id = ${id} FOR UPDATE`);
        const [account] = await tx.select().from(players).where(eq(players.id, id));
        const cash = Number(account.cash);
        if (action === "withdraw" && amount > cash + 0.001) throw new ActionError("Nie masz tylu wolnych środków do wypłaty.");
        await tx.update(players).set({
          cash: moneyString(cash + (action === "deposit" ? amount : -amount)),
          totalDeposited: moneyString(Number(account.totalDeposited) + (action === "deposit" ? amount : -amount)),
        }).where(eq(players.id, id));
        await tx.insert(transactions).values({ playerId: id, kind: action, amount: moneyString(amount) });
      });
    } else if (action === "trade") {
      const symbol = String(body.symbol ?? "");
      const side = body.side;
      const asset = getAsset(symbol);
      const requestedQuantity = Number(body.quantity);
      if (!asset || (side !== "buy" && side !== "sell")) throw new ActionError("Wybierz poprawną transakcję.");
      if (!Number.isFinite(requestedQuantity) || requestedQuantity <= 0 || requestedQuantity > 1_000_000) {
        throw new ActionError("Podaj poprawną ilość aktywa.");
      }
      if (asset.category === "stock" && !Number.isInteger(requestedQuantity)) {
        throw new ActionError("Akcje kupuje się i sprzedaje w pełnych sztukach.");
      }
      const quantity = Number(requestedQuantity.toFixed(8));
      if (quantity <= 0 || Math.abs(quantity - requestedQuantity) > 0.000000001) {
        throw new ActionError("Dla krypto możesz podać maksymalnie 8 miejsc po przecinku.");
      }
      let quote;
      try { quote = await getFreshQuote(symbol); }
      catch (error) { throw new ActionError(error instanceof Error ? error.message : "Nie można pobrać kursu."); }
      const price = quote.price!;
      const amount = roundMoney(price * quantity);
      if (amount < 0.01) throw new ActionError("Wartość transakcji musi wynosić co najmniej 0,01 zł.");
      await db.transaction(async (tx) => {
        await tx.execute(sql`SELECT id FROM players WHERE id = ${id} FOR UPDATE`);
        const [account] = await tx.select().from(players).where(eq(players.id, id));
        const [current] = await tx.select().from(positions).where(and(eq(positions.playerId, id), eq(positions.symbol, symbol)));
        const cash = Number(account.cash);
        if (side === "buy") {
          if (amount > cash + 0.001) throw new ActionError("Za mało wolnych środków. Dodaj środki lub zmniejsz ilość.");
          await tx.update(players).set({ cash: moneyString(cash - amount) }).where(eq(players.id, id));
          if (current) {
            await tx.update(positions).set({
              quantity: (Number(current.quantity) + quantity).toFixed(8),
              costBasis: moneyString(Number(current.costBasis) + amount),
            }).where(and(eq(positions.playerId, id), eq(positions.symbol, symbol)));
          } else {
            await tx.insert(positions).values({ playerId: id, symbol, quantity: quantity.toFixed(8), costBasis: moneyString(amount) });
          }
          const previousBuys = await tx.select({ id: transactions.id }).from(transactions)
            .where(and(eq(transactions.playerId, id), eq(transactions.kind, "buy"))).limit(1);
          if (previousBuys.length === 0) await tx.update(players).set({ xp: account.xp + 25 }).where(eq(players.id, id));
        } else {
          if (!current || Number(current.quantity) + 0.000000001 < quantity) throw new ActionError("Nie masz tylu jednostek w portfelu.");
          const remaining = Number((Number(current.quantity) - quantity).toFixed(8));
          await tx.update(players).set({ cash: moneyString(cash + amount) }).where(eq(players.id, id));
          if (remaining <= 0) {
            await tx.delete(positions).where(and(eq(positions.playerId, id), eq(positions.symbol, symbol)));
          } else {
            await tx.update(positions).set({
              quantity: remaining.toFixed(8),
              costBasis: moneyString(Number(current.costBasis) * remaining / Number(current.quantity)),
            }).where(and(eq(positions.playerId, id), eq(positions.symbol, symbol)));
          }
        }
        await tx.insert(transactions).values({
          playerId: id, kind: side, symbol, quantity: quantity.toFixed(8),
          price: price.toFixed(4), amount: moneyString(amount),
        });
      });
      execution = { price, amount, source: quote.source, side, symbol, quantity };
    } else if (action === "lesson") {
      const lesson = LESSONS.find((item) => item.id === body.lessonId);
      if (!lesson) throw new ActionError("Nie znaleziono tej lekcji.");
      await db.transaction(async (tx) => {
        await tx.execute(sql`SELECT id FROM players WHERE id = ${id} FOR UPDATE`);
        const [completed] = await tx.select().from(lessonCompletions).where(and(
          eq(lessonCompletions.playerId, id), eq(lessonCompletions.lessonId, lesson.id),
        ));
        if (!completed) {
          if (body.answer !== lesson.correct) throw new ActionError("To nie jest poprawna odpowiedź. Spróbuj ponownie.");
          const [account] = await tx.select().from(players).where(eq(players.id, id));
          await tx.insert(lessonCompletions).values({ playerId: id, lessonId: lesson.id });
          await tx.update(players).set({ xp: account.xp + lesson.xp }).where(eq(players.id, id));
        }
      });
    } else if (action === "reset") {
      await db.transaction(async (tx) => {
        await tx.execute(sql`SELECT id FROM players WHERE id = ${id} FOR UPDATE`);
        await tx.delete(positions).where(eq(positions.playerId, id));
        await tx.delete(transactions).where(eq(transactions.playerId, id));
        await tx.delete(lessonCompletions).where(eq(lessonCompletions.playerId, id));
        await tx.update(players).set({ cash: "25000.00", totalDeposited: "25000.00", xp: 0, createdAt: new Date() }).where(eq(players.id, id));
      });
    } else {
      throw new ActionError("Nieznana operacja.");
    }

    const state = await getState(id);
    return Response.json({ ...state, ...(execution ? { execution } : {}) } satisfies GameResponse, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    if (error instanceof ActionError) return Response.json({ error: error.message }, { status: 400 });
    console.error("Game action error", error);
    return Response.json({ error: "Operacja nie powiodła się. Spróbuj ponownie." }, { status: 500 });
  }
}
