import { integer, numeric, pgTable, primaryKey, serial, text, timestamp, index } from "drizzle-orm/pg-core";

export const players = pgTable("players", {
  id: text("id").primaryKey(),
  cash: numeric("cash", { precision: 20, scale: 2 }).notNull().default("25000.00"),
  totalDeposited: numeric("total_deposited", { precision: 20, scale: 2 }).notNull().default("25000.00"),
  xp: integer("xp").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const positions = pgTable("positions", {
  playerId: text("player_id").notNull().references(() => players.id, { onDelete: "cascade" }),
  symbol: text("symbol").notNull(),
  quantity: numeric("quantity", { precision: 24, scale: 8 }).notNull(),
  costBasis: numeric("cost_basis", { precision: 20, scale: 2 }).notNull(),
}, (table) => [primaryKey({ columns: [table.playerId, table.symbol] })]);

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  playerId: text("player_id").notNull().references(() => players.id, { onDelete: "cascade" }),
  kind: text("kind").notNull(),
  symbol: text("symbol"),
  quantity: numeric("quantity", { precision: 24, scale: 8 }),
  price: numeric("price", { precision: 20, scale: 4 }),
  amount: numeric("amount", { precision: 20, scale: 2 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [index("transactions_player_date_idx").on(table.playerId, table.createdAt)]);

export const lessonCompletions = pgTable("lesson_completions", {
  playerId: text("player_id").notNull().references(() => players.id, { onDelete: "cascade" }),
  lessonId: text("lesson_id").notNull(),
  completedAt: timestamp("completed_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [primaryKey({ columns: [table.playerId, table.lessonId] })]);
